create view totalbill1 as
select `quanlybansung`.`orderofcustomer`.`accountId`                                       AS `accountId`,
       `quanlybansung`.`orderdetail`.`orderId`                                             AS `orderId`,
       sum((`quanlybansung`.`orderdetail`.`quantity` * `quanlybansung`.`product`.`price`)) AS `total`
from ((`quanlybansung`.`orderdetail` join `quanlybansung`.`product` on ((`quanlybansung`.`orderdetail`.`productId` =
                                                                         `quanlybansung`.`product`.`id`)))
         join `quanlybansung`.`orderofcustomer`
              on ((`quanlybansung`.`orderofcustomer`.`id` = `quanlybansung`.`orderdetail`.`orderId`)))
group by `quanlybansung`.`orderdetail`.`orderId`;

