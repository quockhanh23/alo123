create definer = root@localhost view totalbill as
select `quanlybansung`.`orderdetail`.`orderId`                                             AS `orderId`,
       sum((`quanlybansung`.`orderdetail`.`quantity` * `quanlybansung`.`product`.`price`)) AS `total`
from (`quanlybansung`.`orderdetail`
         join `quanlybansung`.`product`
              on ((`quanlybansung`.`orderdetail`.`productId` = `quanlybansung`.`product`.`id`)))
group by `quanlybansung`.`orderdetail`.`orderId`;

