create view customer_views as
select `classicmodels`.`customers`.`customerNumber`  AS `customerNumber`,
       `classicmodels`.`customers`.`customerName`    AS `customerName`,
       `classicmodels`.`customers`.`phone`           AS `phone`,
       `classicmodels`.`customers`.`contactLastName` AS `contactLastName`
from `classicmodels`.`customers`
where (`classicmodels`.`customers`.`city` = 'NYC');

