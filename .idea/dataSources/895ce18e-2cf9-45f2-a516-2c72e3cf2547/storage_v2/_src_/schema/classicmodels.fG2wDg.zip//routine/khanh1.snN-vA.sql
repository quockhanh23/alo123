create
    definer = root@localhost procedure khanh1(OUT name1 varchar(100))
begin
    select * from products where productName = name1;
end;

