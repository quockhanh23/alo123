create
    definer = root@localhost procedure findAllCustomers1()
BEGIN

    SELECT * FROM customers;
    SELECT * FROM employees;

END;

