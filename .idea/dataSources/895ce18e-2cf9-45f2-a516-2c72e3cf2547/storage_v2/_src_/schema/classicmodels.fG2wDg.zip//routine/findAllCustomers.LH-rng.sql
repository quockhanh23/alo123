create
    definer = root@localhost procedure findAllCustomers()
BEGIN

    SELECT * FROM customers where customerNumber = 465;

END;

