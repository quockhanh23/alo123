create
    definer = root@localhost procedure findAllCustomers2()
BEGIN

    SELECT contactLastName FROM customers;


END;

