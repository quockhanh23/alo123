create
    definer = root@localhost procedure tinhtien(IN id int, OUT name1 varchar(100), OUT sum int)
begin
    select price*quantity into sum
    from product;
end;

