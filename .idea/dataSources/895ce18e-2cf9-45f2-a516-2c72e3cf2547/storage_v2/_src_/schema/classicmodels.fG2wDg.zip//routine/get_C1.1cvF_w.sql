create
    definer = root@localhost procedure get_C1(IN input int, OUT output varchar(200))
begin
    set output = (select customer.name from customer where id = input);
end;

