create
    definer = root@localhost procedure khanh(IN name1 varchar(100))
begin
    select * from products where productName = name1;
end;

