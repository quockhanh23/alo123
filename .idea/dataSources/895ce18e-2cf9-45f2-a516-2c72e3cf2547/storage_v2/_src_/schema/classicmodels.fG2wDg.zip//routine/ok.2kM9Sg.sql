create
    definer = root@localhost procedure ok(INOUT age1 int)
begin
    set age1 =  age1 + 1;
end;

